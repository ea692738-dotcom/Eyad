#include <Servo.h>
const byte TRIG_PIN=2, ECHO_PIN=3, SERVO_PIN=9, STATUS_LED=13;
const int DETECT_CM=15;
Servo garageServo;
bool garageOpen=false;
unsigned long lastDetectedAt=0;
const unsigned long CLOSE_AFTER_MS=4000;

long readDistanceCm(){
  digitalWrite(TRIG_PIN,LOW); delayMicroseconds(3);
  digitalWrite(TRIG_PIN,HIGH); delayMicroseconds(10);
  digitalWrite(TRIG_PIN,LOW);
  unsigned long duration=pulseIn(ECHO_PIN,HIGH,30000UL);
  if(duration==0) return -1;
  return (long)(duration*0.0343/2.0);
}
void setup(){
  Serial.begin(9600);
  pinMode(TRIG_PIN,OUTPUT); pinMode(ECHO_PIN,INPUT);
  pinMode(STATUS_LED,OUTPUT);
  garageServo.attach(SERVO_PIN); garageServo.write(0);
  digitalWrite(STATUS_LED,LOW);
}
void loop(){
  long d=readDistanceCm();
  if(d>0 && d<=DETECT_CM){
    garageServo.write(90); garageOpen=true; lastDetectedAt=millis();
    digitalWrite(STATUS_LED,HIGH);
    Serial.println(F("Car detected - garage open"));
  }
  if(garageOpen && millis()-lastDetectedAt>=CLOSE_AFTER_MS){
    garageServo.write(0); garageOpen=false; digitalWrite(STATUS_LED,LOW);
    Serial.println(F("Garage closed"));
  }
  delay(100);
}
