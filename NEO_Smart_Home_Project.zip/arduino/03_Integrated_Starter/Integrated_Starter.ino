/*
  NEO Smart Home - integrated starter skeleton.
  It demonstrates lights, PIR alarm, soil and leak readings only.
  Add keypad, servos and LCD after resolving pin conflicts.
  Do not drive a pump directly from an Arduino pin.
*/
const byte ROOM_LIGHT=4, KITCHEN_LIGHT=5, BATH_LIGHT=6;
const byte PIR_PIN=7, BUZZER_PIN=12;
const byte SOIL_PIN=A0, LEAK_PIN=A1;
const int SOIL_DRY_THRESHOLD=600; // calibrate sensor
const int LEAK_THRESHOLD=500;     // calibrate sensor
bool awayMode=false;
bool nightMode=false;

void setup(){
  Serial.begin(9600);
  pinMode(ROOM_LIGHT,OUTPUT); pinMode(KITCHEN_LIGHT,OUTPUT);
  pinMode(BATH_LIGHT,OUTPUT); pinMode(PIR_PIN,INPUT);
  pinMode(BUZZER_PIN,OUTPUT);
  Serial.println(F("NEO Smart Home starter"));
}
void loop(){
  int soil=analogRead(SOIL_PIN), leak=analogRead(LEAK_PIN);
  bool motion=digitalRead(PIR_PIN)==HIGH;
  bool leakDetected=leak>LEAK_THRESHOLD;
  bool soilDry=soil>SOIL_DRY_THRESHOLD;
  digitalWrite(ROOM_LIGHT,nightMode?HIGH:LOW);
  digitalWrite(KITCHEN_LIGHT,nightMode?HIGH:LOW);
  digitalWrite(BATH_LIGHT,LOW);
  bool alarm=(awayMode && motion) || leakDetected;
  digitalWrite(BUZZER_PIN,alarm?HIGH:LOW);
  Serial.print(F("Soil="));Serial.print(soil);
  Serial.print(F(" Leak="));Serial.print(leak);
  Serial.print(F(" Motion="));Serial.print(motion);
  Serial.print(F(" SoilDry="));Serial.print(soilDry);
  Serial.print(F(" LeakDetected="));Serial.println(leakDetected);
  delay(500);
}
