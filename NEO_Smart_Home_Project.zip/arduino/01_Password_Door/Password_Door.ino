#include <Keypad.h>
#include <Servo.h>

const byte ROWS=4, COLS=4;
char keys[ROWS][COLS]={{'1','2','3','A'},{'4','5','6','B'},{'7','8','9','C'},{'*','0','#','D'}};
byte rowPins[ROWS]={2,3,4,5};
byte colPins[COLS]={6,7,8,9};
Keypad keypad=Keypad(makeKeymap(keys),rowPins,colPins,ROWS,COLS);
Servo doorServo;
const byte SERVO_PIN=10;
const String PASSWORD="1234"; // كلمة مرور تجريبية غيّرها لاحقًا
String entered="";
bool doorOpen=false;
unsigned long openedAt=0;
const unsigned long OPEN_MS=3000;

void setup(){
  Serial.begin(9600);
  doorServo.attach(SERVO_PIN);
  doorServo.write(0);
  Serial.println(F("NEO Smart Home - Password Door"));
  Serial.println(F("Enter digits, # submit, * clear"));
}
void loop(){
  char key=keypad.getKey();
  if(key){
    if(key>='0' && key<='9'){
      if(entered.length()<4) entered+=key;
      Serial.println(F("Digit entered"));
    } else if(key=='*'){
      entered="";
      Serial.println(F("Input cleared"));
    } else if(key=='#'){
      if(entered==PASSWORD){
        doorServo.write(90); doorOpen=true; openedAt=millis();
        Serial.println(F("Access granted"));
      } else {
        Serial.println(F("Wrong password"));
      }
      entered="";
    }
  }
  if(doorOpen && millis()-openedAt>=OPEN_MS){
    doorServo.write(0); doorOpen=false;
    Serial.println(F("Door locked"));
  }
}
